<aside>
    <ul>
        <li><a href="dashboard.php">Dashboard</a></li>
        <li><a href="pemasukan.php">Pemasukan</a></li>
        <li><a href="pengeluaran.php">Pengeluaran</a></li>
        <li><a href="pendapatan_bersih.php">Pendapatan Bersih</a></li>
        <li><a href="grafik.php">Grafik</a></li>
        <li><a href="logout.php">Logout</a></li>
    </ul>
</aside>