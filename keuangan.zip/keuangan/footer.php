<footer>
    <p>&copy; 2025 Aplikasi Keuangan</p>
</footer>
</body>
</html>